var CACHE='invpro-v3';
var CORE=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
var LIBS=[
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'
];
self.addEventListener('install',function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){
    return c.addAll(CORE).then(function(){
      return Promise.all(LIBS.map(function(u){
        return fetch(u,{mode:'no-cors'}).then(function(r){return c.put(u,r);}).catch(function(){});
      }));
    });
  }).then(function(){return self.skipWaiting();}));
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));
  }).then(function(){return self.clients.claim();}));
});
self.addEventListener('fetch',function(e){
  var req=e.request;
  if(req.method!=='GET') return;
  var url=new URL(req.url);
  var sameOrigin=url.origin===self.location.origin;
  var isLib=LIBS.indexOf(req.url)>-1;
  if(!sameOrigin&&!isLib) return;
  var isPage=req.mode==='navigate'||/\/(index\.html)?$/.test(url.pathname);
  if(isPage){
    // صفحه اصلی: اول شبکه (برای گرفتن نسخه جدید)، اگر نبود از حافظه
    e.respondWith(
      fetch(req).then(function(res){
        if(res&&res.ok){ var copy=res.clone(); caches.open(CACHE).then(function(c){c.put('./index.html',copy);}); }
        return res;
      }).catch(function(){ return caches.match('./index.html'); })
    );
    return;
  }
  e.respondWith(
    caches.match(req,{ignoreSearch:true}).then(function(hit){
      var net=fetch(req).then(function(res){
        if(res&&(res.ok||res.type==='opaque')){
          var copy=res.clone();
          caches.open(CACHE).then(function(c){c.put(req,copy);});
        }
        return res;
      }).catch(function(){ return hit; });
      return hit||net;
    })
  );
});
